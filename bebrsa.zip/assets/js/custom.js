"use strict";

import { user } from "./mock.js";

let answers = {
  answer1: [],
  answer2: [],
  answer3: [],
  answer4: [],
};

const comments = [];

$(document).on("click", function (e) {
  if ($(e.target).closest("#q1") && !($("#q1").css("display") == "none")) {
    let qNumber = $(e.target).closest($(`div[id]`));
    let dataBg = $(e.target).closest($(`div[data-bq]`));
    answers.answer1.push(qNumber.attr("id"));
    answers.answer1.push(dataBg.attr("data-bq"));
    answers.answer1.push(e.target.innerText);
  } else if (
    $(e.target).closest("#q2") &&
    !($("#q2").css("display") == "none")
  ) {
    let qNumber = $(e.target).closest($(`div[id]`));
    let dataBg = $(e.target).closest($(`div[data-bq]`));
    answers.answer2.push(qNumber.attr("id"));
    answers.answer2.push(dataBg.attr("data-bq"));
    answers.answer2.push(e.target.innerText);
  } else if (
    $(e.target).closest("#q3") &&
    !($("#q3").css("display") == "none")
  ) {
    let qNumber = $(e.target).closest($(`div[id]`));
    let dataBg = $(e.target).closest($(`div[data-bq]`));
    answers.answer3.push(qNumber.attr("id"));
    answers.answer3.push(dataBg.attr("data-bq"));
    answers.answer3.push(e.target.innerText);
  } else if (
    $(e.target).closest("#q4") &&
    !($("#q4").css("display") == "none")
  ) {
    let qNumber = $(e.target).closest($(`div[id]`));
    let dataBg = $(e.target).closest($(`div[data-bq]`));
    answers.answer4.push(qNumber.attr("id"));
    answers.answer4.push(dataBg.attr("data-bq"));
    answers.answer4.push(e.target.innerText);
  } else {
    return null;
  }
});

function showAnswers() {
  let str = "";
  for (let key in answers) {
    str += "Question: " + answers[key].at(0) + `\n`;
    str += "Number of answer(data-bg): " + answers[key].at(1) + `\n`;
    str += "Answer: " + answers[key].at(2) + `\n` + `\n`;
  }
  console.log(str);
}

jQuery("#p_modal_button3").on("click", function (e) {
  e.stopPropagation(), jQuery("#p_modal3").modal("hide"), showAnswers();
  jQuery(".div_img_gift, .img_gift").fadeOut("slow");
});

// ----------------------------------------------------------------------------------------

let COMMENTS = $("div[id*='comment']");

$("input.comment__btn").on("click", function (e) {
  e.preventDefault();
  let text = $("textarea.comment__text");
  if (text[0].value == "") {
    alert("Fill in the field");
  } else {
    let divComment = document.createElement("div");
    divComment.classList.add("comments");
    divComment.setAttribute("id", "comment0");
    divComment.style.display = "block";
    $(".comment").after(divComment);

    let divProfile = document.createElement("div");
    divProfile.classList.add("profile");
    let divContent = document.createElement("div");
    divContent.classList.add("comment-content");
    let divClr = document.createElement("div");
    divClr.classList.add("clr");
    let divStatus = document.createElement("div");
    divStatus.classList.add("comment-status");

    $(divComment).append(divProfile);
    $(divComment).append(divContent);
    $(divComment).append(divClr);
    $(divComment).append(divStatus);

    let img = document.createElement("img");
    img.setAttribute("src", user.avatar);
    divProfile.append(img);

    let pName = document.createElement("p");
    let p = document.createElement("p");
    pName.classList.add("name");
    divContent.append(pName);
    divContent.append(p);

    let fontName = document.createElement("font");
    fontName.style.verticalAlign = "inherit";
    fontName.innerText = user.name;
    pName.append(fontName);

    let fontBody = document.createElement("font");
    fontBody.style.verticalAlign = "inherit";
    fontBody.innerText = text[0].value;
    text[0].value = null;
    p.append(fontBody);

    let span = document.createElement("span");
    divStatus.append(span);

    let fontCurte = document.createElement("font");
    fontCurte.style.verticalAlign = "inherit";
    fontCurte.innerText = "Curte·comente";
    span.append(fontCurte);

    let icon = document.createElement("img");
    icon.setAttribute("src", "assets/images/icons/like.png");
    icon.setAttribute("width", "15px");
    icon.setAttribute("height", "15px");
    span.append(icon);

    let fontLikes = document.createElement("font");
    fontLikes.style.verticalAlign = "inherit";
    fontLikes.innerText = 0;
    span.append(fontLikes);

    let smallDecor = document.createElement("small");
    divStatus.append(smallDecor);

    let fontDecor = document.createElement("font");
    fontDecor.style.verticalAlign = "inherit";
    fontDecor.innerText = "·";
    smallDecor.append(fontDecor);

    let smallDate = document.createElement("small");
    divStatus.append(smallDate);

    let u = document.createElement("u");
    smallDate.append(u);

    let fontDate = document.createElement("font");
    fontDate.style.verticalAlign = "inherit";
    let date = new Date();
    let res = 0;
    if (new Date() - date == 0) {
      res = 1;
    } else {
      res = new Date() - date;
    }
    fontDate.innerText = res + " minutos antes";
    u.append(fontDate);

    for (let i = 0; i < COMMENTS.length; i++) {
      let id = $(COMMENTS[i]).attr("id");
      let number = id.replaceAll("comment", "");
      $(COMMENTS[i]).attr("id", "comment" + ++number);
    }
    COMMENTS = $("div[id*='comment']");
  }
});
