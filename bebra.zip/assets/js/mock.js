export const user = {
  avatar: "assets/images/avatars/user.png",
  name: "UserName",
};
